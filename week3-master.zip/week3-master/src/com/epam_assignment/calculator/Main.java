package com.epam_assignment.calculator;

public class Main {

	public static void main(String[] args) {
		CalcInterface ci=new CalcInterface();
		ci.runInterface();
		System.out.println("Shutting down......!!");
	}
}
